const sum = (a, b) => ({
    a: a,
    b: b,
    sum: a + b
});

console.log(sum(3, 5))
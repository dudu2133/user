const numbers = ["a", "b", "c", "d"];

// const {
//     0: n1,
//     1: n2
// } = numbers;

// let n1, n2;
// ([n1, n2] = numbers);

const [n1, n2] = numbers;

console.log(n1, n2)